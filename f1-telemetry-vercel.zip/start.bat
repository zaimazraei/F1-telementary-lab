@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run setup.bat first to install the project.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" scripts\launch.py
pause
